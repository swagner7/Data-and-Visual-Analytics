import fastf1
import time
fastf1.Cache.enable_cache('cache')

year_races = [
    (2018, 21),
    (2019, 21),
    (2020,17),
    (2021,22),
    (2022,20), #20/22 completed this year
]
for year in year_races:
        for i in range(1, year[1]+1):
            race = fastf1.get_session(year[0], i, 'R')
            race.load()
            time.sleep(1)
