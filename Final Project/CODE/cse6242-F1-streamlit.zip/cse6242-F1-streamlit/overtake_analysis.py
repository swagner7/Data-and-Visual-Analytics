from typing import List

import pandas as pd
import numpy as np
import plotly.express as px
from sklearn.cluster import KMeans
from plotly.graph_objects import Figure
import streamlit as st

from utils import Race, data_loader, filter_session_active


def overtake_analysis(race: Race) -> List[Figure]:
    """Cleans data and calculates number of overtakes, time spent attacking/defending,
    and overtake efficiency
    """
    ## merge timestamps prior to join
    race.gap.sort_values("Time", inplace=True)
    race.sector_times.sort_values("Time", inplace=True)

    # Gap data comes at random intervals in [.25s, 1 lap] seemingly dependent on car proximity, sector data is one lap
    overtake = pd.merge_asof(
        race.gap, race.sector_times, on="Time", by="Driver", direction="forward"
    )

    # Identify when a overtake occurs. -1 = overtake, 0 = hold position, 1 = lost position, 2+ = driver probably did an oops
    overtake["PositionPrev"] = overtake.groupby("Driver")["Position"].shift()
    overtake["PositionChange"] = overtake["Position"] - overtake["PositionPrev"]

    overtake["PositionBehind"] = overtake["Position"] + 1

    # Clean interval data. The leader will have records like 'LAP 21', others will have something like '+1.230'
    overtake.IntervalToPositionAhead = overtake.IntervalToPositionAhead.fillna('0')
    overtake.loc[
        overtake.IntervalToPositionAhead.str.contains("LAP", na=False),
        "IntervalToPositionAhead",
    ] = '0'
    
    overtake.loc[overtake["IntervalToPositionAhead"].str.contains("1 L|2 L|3 L|16 L", regex=True), "IntervalToPositionAhead"] = None
    overtake.IntervalToPositionAhead = overtake.IntervalToPositionAhead.astype(float)

    # Clean gap to leader. Same issue as interval data
    overtake.GapToLeader = overtake.GapToLeader.fillna('0')
    overtake.loc[overtake["GapToLeader"].str.contains("L"), "GapToLeader"] = None
    overtake.GapToLeader = overtake.GapToLeader.astype(float)

    # Self join on position=position behind to get information on driver following and their delta
    overtake = pd.merge_asof(
        overtake,
        overtake[["Time", "Driver", "Position", "IntervalToPositionAhead"]],
        on="Time",
        left_by="PositionBehind",
        right_by="Position",
        direction="forward",
    )
    overtake.drop(columns=["Position_y", "PositionBehind"], inplace=True)
    overtake.rename(
        columns={
            "Driver_y": "DriverBehind",
            "IntervalToPositionAhead_y": "IntervalToPositionBehind",
            "Driver_x": "Driver",
            "Position_x": "Position",
            "IntervalToPositionAhead_x": "IntervalToPositionAhead",
        },
        inplace=True,
    )

    # Some flags to qualify overtakes and identify overtakes due to pits
    overtake["Attacking"] = overtake["IntervalToPositionAhead"] <= 1.0
    overtake["Defending"] = overtake["IntervalToPositionBehind"] <= 1.0
    overtake["Pit"] = overtake["PitOutTime"].notna() & (overtake["NumberOfLaps"] != 1)

    # Self join to determine if driver ahead is in the pits. Useful to filter out false positive overtakes
    overtake["PositionAhead"] = overtake["Position"] - 1
    overtake = overtake.sort_values("Time")
    overtake = pd.merge_asof(
        overtake,
        overtake[["Time", "Driver", "Position", "Pit"]],
        on="Time",
        left_by=["Driver", "PositionAhead"],
        right_by=["Driver", "Position"],
        direction="backward",
    )
    overtake.rename(
        columns={"Position_x": "Position", "Pit_x": "Pit", "Pit_y": "PitAhead"},
        inplace=True,
    )
    # Filter out false positive overtakes based on pit data
    overtake.loc[overtake["Pit"] == True, "PositionChange"] = 0
    overtake.loc[overtake["PitAhead"] == True, "PositionChange"] = 0

    overtake["Time"] = pd.to_timedelta(overtake["Time"])
    overtake["TimeDelta"] = (
        overtake["Time"] - overtake.groupby("Driver")["Time"].shift()
    )

    overtake = overtake.merge(
        race.driver_info[["RacingNumber", "TeamName", "LastName"]],
        left_on="Driver",
        right_on="RacingNumber",
    )

    stats = _overtaking_stats(overtake)
    plots = _make_graphs(stats, overtake)
    return plots,stats


def _overtaking_stats(overtake: pd.DataFrame) -> pd.DataFrame:
    """Inputs raw gap/sector timing data from overtake analysis and calculates a few summary statistics

    Args:
        overtake (pd.DataFrame): overtaking stats

    Returns:
        pd.DataFrame: summary stats
    """
    overtakes = (
        overtake.loc[overtake["PositionChange"] == -1]
        .groupby("LastName")["PositionChange"]
        .sum()
        * -1
    )
    attacking = (
        overtake.loc[overtake["Attacking"]]
        .groupby("LastName")["TimeDelta"]
        .sum()
        .dt.seconds
        / 60
    )
    defending = (
        overtake.loc[overtake["Defending"]]
        .groupby("LastName")["TimeDelta"]
        .sum()
        .dt.seconds
        / 60
    )
    stats = pd.concat(
        {
            "Overtakes": overtakes,
            "AttackingTime": attacking,
            "DefendingTime": defending,
        },
        axis=1,
    ).reset_index()
    stats["OvertakeEfficiency"] = stats["Overtakes"] / stats["AttackingTime"]
    stats.sort_values("OvertakeEfficiency", ascending=False)

    return stats


def _make_graphs(stats: pd.DataFrame, overtake: pd.DataFrame) -> List[Figure]:
    """Converts the result of overtaking_stats into visualizations

    Args:
        stats (pd.DataFrame): overtaking stats
        overtake(pd.DataFrame): raw overtake data from overtake analysis

    Returns:
        List[Figure]: plotly graphs to display on dashboard
    """
    overtakes = px.bar(
        stats.sort_values("Overtakes", ascending=False),
        x="LastName",
        y="Overtakes",
        title="On Track Overtakes",
    )
    attacking = px.bar(
        stats.sort_values("AttackingTime", ascending=False),
        x="LastName",
        y="AttackingTime",
        title="Time Spent within 1 second of car ahead (mins)",
    )
    defending = px.bar(
        stats.sort_values("DefendingTime", ascending=False),
        x="LastName",
        y="DefendingTime",
        title="Time Spent with car behind within 1 second (mins)",
    )
    efficiency = px.bar(
        stats.sort_values("OvertakeEfficiency", ascending=True),
        x="LastName",
        y="OvertakeEfficiency",
        title="Time spent setting up overtake (mins)",
    )
    gap = px.line(
        overtake,
        x="Time",
        y="GapToLeader",
        color="LastName",
        title="Gap to Leader (seconds)",
    )
    return [overtakes, attacking, defending, efficiency, gap]

@st.cache(allow_output_mutation=True)
def overtake_analysis_season(select_year, race_list):
    overtake_stats_totals = pd.DataFrame(columns=['LastName','Overtakes','AttackingTime','DefendingTime'])
    overtake_stats_totals.index.name = 'LastName'
    for race_name in race_list:
        race = data_loader(year=select_year, race=race_name)
        race = filter_session_active(race)
        _,overtake_stats = overtake_analysis(race)
        overtake_stats_totals = pd.concat([overtake_stats_totals,overtake_stats],axis=0)
    overtake_stats_totals = overtake_stats_totals.groupby(['LastName'])['Overtakes','AttackingTime','DefendingTime'].sum()
    overtake_stats_totals.reset_index(level=0, inplace=True)
    overtake_stats_totals["OvertakeEfficiency"] = overtake_stats_totals["Overtakes"] / overtake_stats_totals["AttackingTime"]
    overtake_stats_totals.sort_values("OvertakeEfficiency", ascending=False)
    plots = _make_graphs_season(overtake_stats_totals)
    return plots,overtake_stats_totals
    

def _make_graphs_season(stats: pd.DataFrame) -> List[Figure]:
    """Converts the result of overtaking_stats into visualizations

    Args:
        stats (pd.DataFrame): overtaking stats
        overtake(pd.DataFrame): raw overtake data from overtake analysis

    Returns:
        List[Figure]: plotly graphs to display on dashboard
    """
    overtakes = px.bar(
        stats.sort_values("Overtakes", ascending=False),
        x="LastName",
        y="Overtakes",
        title="On Track Overtakes",
    )
    attacking = px.bar(
        stats.sort_values("AttackingTime", ascending=False),
        x="LastName",
        y="AttackingTime",
        title="Time Spent within 1 second of car ahead (mins)",
    )
    defending = px.bar(
        stats.sort_values("DefendingTime", ascending=False),
        x="LastName",
        y="DefendingTime",
        title="Time Spent with car behind within 1 second (mins)",
    )
    efficiency = px.bar(
        stats.sort_values("OvertakeEfficiency", ascending=True),
        x="LastName",
        y="OvertakeEfficiency",
        title="Time spent setting up overtake (mins)",
    )

    return [overtakes, attacking, defending, efficiency]
