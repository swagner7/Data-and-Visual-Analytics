import numpy as np
import matplotlib as mpl
import pandas as pd
from utils import data_loader, filter_session_active

from matplotlib import pyplot as plt
from matplotlib.collections import LineCollection

def get_overtake_data(race,driver):

    data = []

    driver_num = race.driver_info
    driver_num = driver_num[driver_num['FullName'] == driver]['RacingNumber'].iloc[0]
    car_data = race.car_data
    car_data = car_data[(car_data['driver'] == driver_num)]
    pos_data = race.position_data
    pos_data = pos_data[(pos_data['driver'] == driver_num)]
    gap_data = race.gap
    gap_data = gap_data[(gap_data['Driver'] == driver_num)]
    gap_data.rename({'Driver':'driver'}, axis=1, inplace=True)
    full_tel  = pd.merge_asof(
        car_data.sort_values('Time'), pos_data.sort_values('Time'), on="Time", by='driver', direction="forward"
    )
    full_tel  = pd.merge_asof(
        full_tel.sort_values('Time'), gap_data.sort_values('Time'), on="Time", by='driver', direction="forward"
    )
    full_tel.IntervalToPositionAhead = full_tel.IntervalToPositionAhead.fillna('0')
    full_tel.loc[
        full_tel.IntervalToPositionAhead.str.contains("LAP", na=False),
        "IntervalToPositionAhead",
    ] = '0'
    
    full_tel.loc[full_tel["IntervalToPositionAhead"].str.contains("1 L|2 L|3 L|16 L", regex=True), "IntervalToPositionAhead"] = None
    full_tel.IntervalToPositionAhead = full_tel.IntervalToPositionAhead.astype(float)
    full_tel = full_tel[full_tel['Position'].notna()]
    first_point = True

    for i, val in full_tel["DRS"].items():
        drs = val
        x = full_tel["X"].loc[i]
        y = full_tel["Y"].loc[i]
        driver_ahead = full_tel["Position"].loc[i]
        distance_to_driver_ahead = full_tel["IntervalToPositionAhead"].loc[i]

        if first_point is False:
            prev_driver_ahead = full_tel["Position"].loc[i-1]
            prev_distance_to_driver_ahead = full_tel["IntervalToPositionAhead"].loc[i-1]

            if prev_driver_ahead != '' and int(driver_ahead) != int(prev_driver_ahead): #tune and add check with distance
                temp_dict = {
                    "pos": (x,y),
                    "driver_ahead": driver_ahead,
                    "prev_driver_ahead": prev_driver_ahead,
                    "DRS":drs
                }
                if int(driver_ahead) < int(prev_driver_ahead):
                    temp_dict['overtake'] = 'take' 
                    if prev_distance_to_driver_ahead < 1:
                        temp_dict['true_overtake'] = True
                    else:
                        temp_dict['true_overtake'] = False
                else:
                    temp_dict['overtake'] = 'lose' 
                    if distance_to_driver_ahead < 1:
                        temp_dict['true_overtake'] = True
                    else:
                        temp_dict['true_overtake'] = False
                data.append(temp_dict)

        first_point = False

    return data


def plot_track(race, driver):
    try:
        colormap = mpl.cm.inferno
        
        best_lap = race.sector_times
        driver_num = race.driver_info
        driver_num = driver_num[driver_num['FullName'] == driver]['RacingNumber'].iloc[0]
        best_lap = best_lap[(best_lap['Driver'] == driver_num)]
        best_lap_number = np.where(best_lap.LapTime == best_lap.LapTime.min())[0][0]
        bl_start = best_lap.iloc[best_lap_number - 1,0]
        bl_end = best_lap.iloc[best_lap_number,0]
        car_data = race.car_data
        car_data = car_data[(car_data['driver'] == driver_num) & (car_data['Time'] >= bl_start) & (car_data['Time'] <= bl_end)]
        pos_data = race.position_data
        pos_data = pos_data[(pos_data['driver'] == driver_num) & (pos_data['Time'] >= bl_start) & (pos_data['Time'] <= bl_end)]
        bl_tel  = pd.merge_asof(
            car_data.sort_values('Time'), pos_data.sort_values('Time'), on="Time", by='driver', direction="forward"
        )
    
        # Get telemetry data from lap
        x = bl_tel['X']
        y = bl_tel['Y']
        color = bl_tel['Speed']  # value to base color gradient on
    
        points = np.array([x, y]).T.reshape(-1, 1, 2)
        segments = np.concatenate([points[:-1], points[1:]], axis=1)
    
        # create plot
        fig, ax = plt.subplots(sharex=True, sharey=True, figsize=(12, 6.75))
        #fig.suptitle(f'Overtakes by {driver}', size=25, y=1)
        ax.axis('off')
    
        #track line
        ax.plot(x, y, color='black', linestyle='-', linewidth=32, zorder=0)
    
    
        # Create a continuous norm to map from data points to colors
        norm = plt.Normalize(color.min(), color.max())
        lc = LineCollection(segments, cmap=colormap, norm=norm, linestyle='-', linewidth=20)
    
        # Set the values used for colormapping
        lc.set_array(color)
    
        # Merge all line segments together
        line = ax.add_collection(lc)
    
        # Finally, we create a color bar as a legend.
        # cbaxes = fig.add_axes([0.25, 0.05, 0.5, 0.05])
        # normlegend = mpl.colors.Normalize(vmin=color.min(), vmax=color.max())
        # legend = mpl.colorbar.ColorbarBase(cbaxes, norm=normlegend, cmap=colormap, orientation="horizontal")
    
        # Plot overtaking points
        overtake_coords = get_overtake_data(race,driver)
        point_size = 120
        point_color = (1, 1, 1, 0.75)
        edge_color = 'green'
        if len(overtake_coords) > 0:
            for data in overtake_coords:
                coords = data["pos"]
                drs = data["DRS"]
        
                if drs == 1 and data['true_overtake'] == True and data['overtake'] == 'take':
                    edge_color = (0, 1, 0, 0.75) #green
                elif drs == 0 and data['true_overtake'] == True and data['overtake'] == 'take':
                    edge_color = (0, 0, 1, 0.75) #blue
                elif data['true_overtake'] == True and data['overtake'] == 'lose':
                    edge_color = (1, 0, 0, 0.75) #red
                elif data['true_overtake'] == False and data['overtake'] == 'lose':
                    edge_color = (.5, .5, .5, 0.75) #grey
                elif data['true_overtake'] == False and data['overtake'] == 'take':
                    edge_color = (1, 0, 1, 0.75) #purple
                else:
                    edge_color = (1, 0, 0, 0.75) #red
        
                overtaking_point = plt.Circle(coords, radius=point_size, facecolor=point_color, edgecolor=edge_color,
                                              linewidth=7, zorder=10)
                ax.add_patch(overtaking_point)
        
        
            green_dot = plt.Circle(coords, radius=point_size, facecolor=point_color, edgecolor=(0, 1, 0, 0.75),
                                              linewidth=7, zorder=10)
            blue_dot = plt.Circle(coords, radius=point_size, facecolor=point_color, edgecolor=(0, 0, 1, 0.75),
                                              linewidth=7, zorder=10)
            red_dot = plt.Circle(coords, radius=point_size, facecolor=point_color, edgecolor=(1, 0, 0, 0.75),
                                              linewidth=7, zorder=10)
            grey_dot = plt.Circle(coords, radius=point_size, facecolor=point_color, edgecolor=(.5, .5, .5, 0.75),
                                              linewidth=7, zorder=10)
            purple_dot = plt.Circle(coords, radius=point_size, facecolor=point_color, edgecolor=(1, 0, 1, 0.75),
                                              linewidth=7, zorder=10)
        
            plt.legend([green_dot,blue_dot,red_dot,grey_dot,purple_dot], ["Overtake with DRS","Overtake without DRS","Overtaken","Non overtake postition loss","Non overtake position take"])
        

    except:
        fig, ax = plt.subplots()
        plt.title('Unknow Error in Driver Data')


    return fig
