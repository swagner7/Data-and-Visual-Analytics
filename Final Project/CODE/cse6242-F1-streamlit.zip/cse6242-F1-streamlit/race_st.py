
from st_on_hover_tabs import on_hover_tabs

from overtake_analysis import overtake_analysis, overtake_analysis_season
from tire_analysis import tire_analysis
from plot_overtake import plot_track
from utils import data_loader, filter_session_active, data_loader_season
from Track_satView import make_satView
import streamlit as st
from sklearn.cluster import KMeans
import os
import numpy as np
import plotly.express as px
import ipywidgets
import pandas as pd
import streamlit.components.v1 as components

st.set_page_config(layout="wide",initial_sidebar_state="auto")
st.header("Formula 1 Analysis")
# st.markdown('<div style="text-align: center; font-size: 3em">Formula 1 Racing Analyis</div>', unsafe_allow_html=True)









def races_page():
    year_list = [int(name.replace("year=",'')) for name in os.listdir("position_data")]
    
    
    select_year = st.selectbox("Year", year_list, len(year_list)-1)
    race_list = [name.replace("race=",'') for name in os.listdir(f"position_data/year={select_year}")]
    race_list_clean = [race[11:].replace('_', ' ') for race in race_list]
    select_race = st.selectbox("Race", race_list_clean, len(race_list_clean)-1)
    race = data_loader(year=select_year, race=race_list[race_list_clean.index(select_race)])


    sat_plot = make_satView(select_race, select_year, race)
    st.plotly_chart(sat_plot,use_container_width=True)
    st.header("Overtake")
    
    race = data_loader(year=select_year, race=race_list[race_list_clean.index(select_race)])
    race = filter_session_active(race)
    overtake_plots,overtake_stats = overtake_analysis(race)
    col1, col2= st.columns(2)
    
    for plot in overtake_plots[:4:2]:
        col1.plotly_chart(plot,use_container_width=True)
    
    
    for plot in overtake_plots[1::2]:
        col2.plotly_chart(plot,use_container_width=True)
        
    
    overtake_stats_list = list(overtake_stats.columns)[1:]
    st.subheader('Kmeans Clustering of Drivers Overtake Ability')
    axis1 = st.selectbox("Clustering Plot Axis 1", overtake_stats_list)
    overtake_stats_list2 = overtake_stats_list.copy()
    overtake_stats_list2.remove(axis1)
    axis2 = st.selectbox("Clustering Plot Axis 2", overtake_stats_list2)
    
    X_overtake = np.array(overtake_stats[[axis1,axis2]].fillna(0))
    km_overtake = KMeans(n_clusters= 3).fit(X_overtake)
    overtake_km_df = overtake_stats[['LastName',axis1,axis2]]
    overtake_km_df['Group'] = km_overtake.labels_
    overtake_km_df['Group'] = overtake_km_df['Group'].astype('str')
    
    overtake_km_plot = px.scatter(overtake_km_df, x=axis1, y=axis2, color='Group', hover_data=['LastName'])
    overtake_km_plot.update_traces(marker=dict(size=12))
    st.plotly_chart(overtake_km_plot,use_container_width=True)
    drivers = race.driver_info[['FullName', 'Tla']]
    drivers.columns =['FullName', 'Driver']   
    drivers.drop_duplicates(inplace=True)
    drivers = list(drivers['FullName'].unique())
    driver = st.selectbox('Select Driver:', options = drivers)
    o_track_plot = plot_track(race, driver)
    st.subheader('Location of Overtakes on Track')
    st.caption('Lap coloring based on best lap. Lower speeds equal darker colors')
    st.pyplot(o_track_plot, use_container_width=True)
    st.header('Tires')
    tire_plot = tire_analysis(select_year, select_race)
    st.subheader('Distribution of Lap Times by Tire Composition')
    st.pyplot(tire_plot, use_container_width=True)
    
def season_page():
    year_list = [int(name.replace("year=",'')) for name in os.listdir("position_data")]
    select_year = st.selectbox("Year", year_list, len(year_list)-1)
    
    
    st.subheader("Overtakes & DRS Deep Dive by Season")
    race_list = [name.replace("race=",'') for name in os.listdir(f"position_data/year={select_year}")]
    overtake_plots, overtake_stats = overtake_analysis_season(select_year,race_list)
    overtake_stats_totals = overtake_stats.copy()
    col1, col2= st.columns(2)
    
    for plot in overtake_plots[:4:2]:
        col1.plotly_chart(plot,use_container_width=True)
    
    
    for plot in overtake_plots[1::2]:
        col2.plotly_chart(plot,use_container_width=True)
        
    overtake_stats_list = list(overtake_stats_totals.columns)[1:]
    st.subheader('Kmeans Clustering of Drivers Overtake Ability')
    axis1 = st.selectbox("Clustering Plot Axis 1", overtake_stats_list)
    overtake_stats_list2 = overtake_stats_list.copy()
    overtake_stats_list2.remove(axis1)
    axis2 = st.selectbox("Clustering Plot Axis 2", overtake_stats_list2)
    
    X_overtake = np.array(overtake_stats_totals[[axis1,axis2]].fillna(0))
    km_overtake = KMeans(n_clusters= 3).fit(X_overtake)
    overtake_km_df = overtake_stats_totals[['LastName',axis1,axis2]]
    overtake_km_df['Group'] = km_overtake.labels_
    overtake_km_df['Group'] = overtake_km_df['Group'].astype('str')
    
    overtake_km_plot = px.scatter(overtake_km_df, x=axis1, y=axis2, color='Group', hover_data=['LastName'])
    overtake_km_plot.update_traces(marker=dict(size=12))
    st.plotly_chart(overtake_km_plot,use_container_width=True)
    
    st.header('Tires')
    tire_plot = tire_analysis(select_year, 'All races', True, True)
    st.subheader('Distribution of Lap Times by Tire Composition')
    st.pyplot(tire_plot)

year_list = [int(name.replace("year=",'')) for name in os.listdir(os.path.join(os.path.dirname(__file__),"position_data"))]
for year in year_list:
    race_list = [name.replace("race=",'') for name in  os.listdir(os.path.join(os.path.dirname(__file__),f"position_data/year={year}"))]
    overtake_analysis_season(year,race_list)

page_names_to_funcs = {
    "Races Page": races_page,
    "Season Page": season_page,
}
st.markdown('<style>' + open('./style.css').read() + '</style>', unsafe_allow_html=True)


def globe_page():
    st.subheader("Give it a spin! Zoom in and see more.")
    components.iframe("https://api.mapbox.com/styles/v1/connernations/clb052nkv002n14n00px0lu4u.html?title=false&access_token=pk.eyJ1IjoiY29ubmVybmF0aW9ucyIsImEiOiJjbGFxYXNsdjkxaDVnM3B0NzdodWN6MXFsIn0.tny5OHVo3KYLvoxY20ZkZg&zoomwheel=false#1.21/70.6/19.9/27.7/64", height = 650)

# with st.sidebar:
#     tabs = on_hover_tabs(tabName=['Race Page','Season Page'], 
#                          iconName=['dashboard','money'], default_choice=0,
#                          styles = {'navtab': {'background-color':'#111',
#                                                 'color': '#818181',
#                                                 'font-size': '18px',
#                                                 'transition': '.3s',
#                                                 'white-space': 'nowrap',
#                                                 'text-transform': 'uppercase'},
#                                     'tabOptionsStyle': {':hover :hover': {'color': 'red',
#                                                                     'cursor': 'pointer'}},
#                                     'iconStyle':{'position':'fixed',
#                                                 'left':'7.5px',
#                                                 'text-align': 'left'},
#                                     'tabStyle' : {'list-style-type': 'none',
#                                                     'background-color':'#111',
#                                                     'margin-bottom': '30px',
#                                                     'padding-left': '30px'}},
#                              key="1")



with st.sidebar:
    tabs = on_hover_tabs(tabName=['Race Page','Season Page','F1 Globe'], 
                         iconName=['360','dashboard','explore'],default_choice=0,
                         styles = {'navtab': {'background-color':'#111',
                                                'color': '#818181',
                                                'font-size': '20px',
                                                'transition': '.3s',
                                                'min-width': '10px',
                                                'max-width': '290px',
                                                'white-space': 'nowrap',
                                                'width': 'auto',
                                                'text-transform': 'uppercase'},
                                    'tabOptionsStyle': {':hover :hover': {'color': 'red',
                                                                    'cursor': 'pointer'}},
                                    'iconStyle':{'position':'fixed',
                                                'left':'7.5px',
                                                'text-align': 'left'},
                                    'tabStyle' : {'list-style-type': 'none',
                                                    # ',background-color':'#111'
                                                    'margin-bottom': '30px',
                                                    'padding-left': '30px'}},
                         key="0")


if tabs =='Race Page':
    st.markdown('<div style="text-align: center; font-size: 3em">Single Race Page</div>', unsafe_allow_html=True)
    races_page()
    # st.title("Race Page")
    st.write(format(tabs))


elif tabs =='Season Page':
    st.markdown('<div style="text-align: center; font-size: 3em"> Full Racing Season Page</div>', unsafe_allow_html=True)
    season_page()
    st.write(format(tabs))

elif tabs =='F1 Globe':
    st.markdown('<div style="text-align: center; font-size: 3em"> F1 globe</div>', unsafe_allow_html=True)
    globe_page()
    st.write(format(tabs))

# with st.sidebar:
#         tabs = on_hover_tabs(tabName=[ "Races Page", "Season Page"], 
#                              iconName=['Season Page', 'season_page'],
#                              key="1")
#         # components.iframe("https://api.mapbox.com/styles/v1/connernations/clb052nkv002n14n00px0lu4u.html?title=false&access_token=pk.eyJ1IjoiY29ubmVybmF0aW9ucyIsImEiOiJjbGFxYXNsdjkxaDVnM3B0NzdodWN6MXFsIn0.tny5OHVo3KYLvoxY20ZkZg&zoomwheel=false#1.21/70.6/19.9/27.7/64", height = 250)

# page_names_to_funcs[tabs]()

# elif tabs == 'Money':
#     st.title("Paper")
#     st.write('Name of option is {}'.format(tabs))

# # with st.sidebar:
#     selected_page = st.sidebar.selectbox("Select a page", page_names_to_funcs.keys())
#     components.iframe("https://api.mapbox.com/styles/v1/connernations/clb052nkv002n14n00px0lu4u.html?title=false&access_token=pk.eyJ1IjoiY29ubmVybmF0aW9ucyIsImEiOiJjbGFxYXNsdjkxaDVnM3B0NzdodWN6MXFsIn0.tny5OHVo3KYLvoxY20ZkZg&zoomwheel=false#1.21/70.6/19.9/27.7/64", height = 250)


# page_names_to_funcs[selected_page]()
