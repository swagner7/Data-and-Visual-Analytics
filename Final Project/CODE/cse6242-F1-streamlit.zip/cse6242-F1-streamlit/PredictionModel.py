from overtake_analysis import overtake_analysis
import pandas as pd
import os
from utils import data_loader, filter_session_active

year_list = [int(name.replace("year=",'')) for name in os.listdir("position_data")]
overtake_stats_totals = pd.DataFrame(columns=['Year','Race','LastName','Overtakes','AttackingTime','DefendingTime'])
for select_year in year_list:
    race_list = [name.replace("race=",'') for name in os.listdir(f"position_data/year={select_year}")]
    for race_name in race_list:
        race = data_loader(year=select_year, race=race_name)
        race = filter_session_active(race)
        _,overtake_stats = overtake_analysis(race)
        overtake_stats['Year'] = select_year
        overtake_stats['Race'] = race_name
        overtake_stats_totals = pd.concat([overtake_stats_totals,overtake_stats],axis=0)
overtake_stats_totals = overtake_stats_totals.fillna(0)
#%%
overtake_stats_totals.to_csv('overtake_stats.csv', index= False)
