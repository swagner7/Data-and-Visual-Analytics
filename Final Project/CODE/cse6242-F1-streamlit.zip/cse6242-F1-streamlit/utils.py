from dataclasses import dataclass
import pandas as pd
import os

@dataclass
class Race:
    year: str
    race: str
    car_data: pd.DataFrame = None
    driver_info: pd.DataFrame = None
    position_data: pd.DataFrame = None
    race_control_messages: pd.DataFrame = None
    session_status_data: pd.DataFrame = None
    timing_app_data: pd.DataFrame = None
    sector_times: pd.DataFrame = None
    gap: pd.DataFrame = None
    track_status_data: pd.DataFrame = None
    weather_data: pd.DataFrame = None
    
@dataclass
class Season:
    year: str
    car_data: pd.DataFrame = None
    driver_info: pd.DataFrame = None
    position_data: pd.DataFrame = None
    race_control_messages: pd.DataFrame = None
    session_status_data: pd.DataFrame = None
    timing_app_data: pd.DataFrame = None
    sector_times: pd.DataFrame = None
    gap: pd.DataFrame = None
    track_status_data: pd.DataFrame = None
    weather_data: pd.DataFrame = None

def Transform_vectorPos_toGeo(race):
    """
    When we multiply a matrix by a scalar (i.e., a single number) we simply multiply all the matrix's terms by that scalar

    Track .geojson files of Geographic Line strings we're used from this open-source license repository as starting raw informaiton
    https://github.com/bacinger/f1-circuits/tree/master/circuits. These we're processsed and cleaned in ArcMap Pro, and then densified as vector points, latitued and longitude (a new Target Vector Matrix) and exported.

    (X,Y,Z) Relative chart coridnates as floats are provdied in the fastf1 API with no meta data information, but we're assumed to be at some point also based on a GPS centroid coridinate.
    """

    oldYMax = race['position_data']['Y'].max()
    oldYMin = race['position_data']['Y'].min()
    oldXMax = race['position_data']['X'].max()
    oldXMin = race['position_data']['X'].min()
    oldYRange = oldYMax - oldYMin
    oldXRange = oldXMax - oldXMin
    DFgeo = os.path.join(os.path.dirname(__file__), 'tracksLatLon.csv')

    #cleaning/matching on track location
    locations = pd.read_csv(os.path.join(os.path.dirname(__file__), 'prix_to_location.csv'))
    locat = locations[(locations['EventName'] == race['race'][11:].replace('_', ' ')) & (locations['Year'] == race['year'])]['Location'].iloc[0]


    # race_list = [name.replace("race=",'') for name in os.listdir(f"position_data/year={year}")]
    # race_list_clean = [race[11:].replace('_', ' ') for race in race_list]
    race['race']
    df = pd.read_csv(DFgeo)
    df = df[df['Location'] == locat]
    df = df[['lat','lon']]    
    newYMax = df['lat'].max()
    newYMin = df['lat'].min()
    newXMax = df['lon'].max()
    newXMin = df['lon'].min()
    newYRange = newYMax - newYMin
    newXRange = newXMax - newXMin
    race['position_data'] = race['position_data'].assign(lat=lambda x: round(((((x['X'] - oldXMin)* newXRange )/ oldXRange) + newXMin),6))
    race['position_data'] = race['position_data'].assign(lon=lambda x: round(((((x['Y'] - oldYMin)* newYRange )/ oldYRange) + newYMin),6))

    return race

def data_loader(year: int, race: str) -> Race:
    """Load data from once race, returns a data container

    Args:
        year (int): 2018-2022
        race (str): race name formatted as YYY-mm-dd_{race}_Grand_Prix
    """
    datasets = [
        "car_data",
        "driver_info",
        "position_data",
        "race_control_messages",
        "session_status_data",
        "timing_app_data",
        "sector_times",
        "gap",
        "track_status_data",
        "weather_data",
    ]
    race_data = {
        "year": year,
        "race": race,
    }
    for dataset in datasets:
        race_data[dataset] = pd.read_parquet(f"{dataset}/year={year}/race={race}")

    race_data = Transform_vectorPos_toGeo(race_data)

    return Race(**race_data)

def data_loader_season(year: int) -> Race:
    """Load data from once race, returns a data container

    Args:
        year (int): 2018-2022
        race (str): race name formatted as YYY-mm-dd_{race}_Grand_Prix
    """
    datasets = [
        "car_data",
        "driver_info",
        "position_data",
        "race_control_messages",
        "session_status_data",
        "timing_app_data",
        "sector_times",
        "gap",
        "track_status_data",
        "weather_data",
    ]
    race_data = {
        "year": year,
    }
    for dataset in datasets:
        for subdir, dirs, files in os.walk(f"{dataset}/year={year}"):
            for file in files:
                race_data[dataset] = pd.read_parquet(os.path.join(subdir, file))

    return Season(**race_data)


def filter_session_active(race: Race) -> Race:
    """Filters data in a Race object based on the session status. Returns a new Race object"""
    min = race.session_status_data.loc[
        race.session_status_data.Status == "Started", "Time"
    ].iloc[0]
    max = race.session_status_data.loc[
        (race.session_status_data.Status == "Finished") | (race.session_status_data.Status == "Aborted"), "Time"
    ].iloc[0]

    race = race.__dict__.copy()  # make a copy to avoid inplace modification
    # Loop through datasets with timing information and filter out data outside of the race
    time_datasets = [
        "car_data",
        "position_data",
        "timing_app_data",
        "sector_times",
        "gap",
        "track_status_data",
        "weather_data",
    ]
    for name, df in race.items():
        if name in time_datasets:
            race[name] = df.loc[df.Time.between(min, max)]

    return Race(**race)
