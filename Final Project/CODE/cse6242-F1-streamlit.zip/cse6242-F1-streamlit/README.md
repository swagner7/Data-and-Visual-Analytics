# cse6242-F1
Semester project, F1 stats

## GCS Bucket cse6242-f1-data:
See `gcp.ipynb` for reading data

* /datasets: merged all race data into a single parquet dataset for each data type
* /2018 - /2022: fastf1 cache data for all races

## Creating environment
Use a environment.yml to create conda environment to ensure the app works. Here are the
dependencies listed in file in case of using another environment.
  - python=3.9
  - streamlit
  - plotly
  - scikit-learn
  - matplotlib

## Launching app
Go to terminal or prompt that your environment is in. Enter the directory the python
and data files are held and run the below command.
>> streamlit run race_st.py

If you are using a non conda enviroment you may need to run
>> python3 -m streamlit run race_st.py

## Description of Files
* `load_data.py` Loops through all races in fastf1 and loads to cache
* `process_data.py` Merges data from cache and produces parquet datasets
* `gcp.ipynb` reads in data from google cloud
* `race_st.py` holds code to launch streamlit app
* `overtake_analysis.py` creates overtake bar plots
* `overatake_experiment.py` Summary overtake visualizations for a season
* `plot_overtake.py` creates overtake points graph
* `tire_analysis` creates plots for tires
* `Track_satView` creates world map of tracks
* `utils.py` assists with data manipulation

## Video Instructions Link
https://youtu.be/3gcMDeX5Xok
