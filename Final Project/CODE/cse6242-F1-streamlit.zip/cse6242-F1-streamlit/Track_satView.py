import pandas as pd
import os
import plotly.graph_objects as px
import numpy as np


def make_satView(race_clean, year, race):
    race
    locations = pd.read_csv(os.path.join(os.path.dirname(__file__), 'prix_to_location.csv'))
    locat = locations[(locations['EventName'] == race_clean) & (locations['Year'] == year)]['Location'].iloc[0]
    token ="pk.eyJ1IjoiY29ubmVybmF0aW9ucyIsImEiOiJjbGFxYXNsdjkxaDVnM3B0NzdodWN6MXFsIn0.tny5OHVo3KYLvoxY20ZkZg"
    DFz = os.path.join(os.path.dirname(__file__), 'circuits_cords.csv')
    df = pd.read_csv(DFz)
    locat_num = df['location'].tolist()
    try:
        num_loc = locat_num.index(locat)
        center_dict = dict(lat=df.loc[:, 'lat'].values[num_loc],
        lon=df.loc[:, 'lng'].values[num_loc])
        zooms = 15.2
    except:
        center_dict = dict(lat=48.498,lon=17.920)
        num_loc = 0
        zooms = 2.5
    mapbox_token='pk.eyJ1IjoiY29ubmVybmF0aW9ucyIsImEiOiJjbGFxYXNsdjkxaDVnM3B0NzdodWN6MXFsIn0.tny5OHVo3KYLvoxY20ZkZg'
    # px.set_mapbox_access_token(mapbox_token)
    
    # GeoCircuits = "/Users/connernations/Downloads/f1-circuits-master/f1-circuits.geojson"
    # fig = px.line_mapbox(center = {"lat":24.467,"lon":54.607},mapbox_style="mapbox://styles/connernations/clb052nkv002n14n00px0lu4u")
    # fig.update_mapboxes(pitch=60, zoom=15.6)
    
    df1 = race.position_data
    maxD = df1["driver"].max()
    print(maxD)
    df2 = df1[df1["driver"].isin([maxD,maxD])]
    print("YEYEYEXQYEY")
    df2
    df2 = df2.iloc[::10]
    # for row in df2.itertuples():
    #     fig.add_scattermapbox(
    #         mode = "markers+lines",
    #         lat = [row.lat],
    #         lon = [row.lon],
    #         marker = {'size': 10}
    #         )
    # print(df2)
    
    fig=px.FigureWidget(px.Scattermapbox(
                   
                   name = "Track",
                   marker=px.scattermapbox.Marker( #showscale=True,
                                        size=14, color = 'green',symbol= "circle",opacity=1, allowoverlap = True
                                        ))

                )

    fig.update_layout(autosize=True,height=900,mapbox=dict(#accesstoken=mapbox_access_token,
                                    
                                    bearing=0,
                                    center=center_dict,
                                    pitch=60,
                                    zoom=zooms,
                                    accesstoken="pk.eyJ1IjoiY29ubmVybmF0aW9ucyIsImEiOiJjbGFxYXNsdjkxaDVnM3B0NzdodWN6MXFsIn0.tny5OHVo3KYLvoxY20ZkZg",
                                    style="mapbox://styles/connernations/clb052nkv002n14n00px0lu4u"));
        
        # frames = [dict(
        #                                        'mapbox.center.lat' = df.loc[:k+1, 'lat'].values[0], 
        #                                        'mapbox.center.lon' = df.loc[:k+1, 'lng'].values[0]    
        #                   )for k  in  range(len(df))  
        # ]


    fig.update_layout(autosize=True,height=900,mapbox=dict(#accesstoken=mapbox_access_token,
                                  
                                  bearing=0,
                                  center=center_dict,
                                  pitch=60,
                                  zoom=zooms,
                                  accesstoken="pk.eyJ1IjoiY29ubmVybmF0aW9ucyIsImEiOiJjbGFxYXNsdjkxaDVnM3B0NzdodWN6MXFsIn0.tny5OHVo3KYLvoxY20ZkZg",
                                  style="mapbox://styles/connernations/clb052nkv002n14n00px0lu4u"));
    
    # fig.add_trace(px.Scattermapbox(below = "",
    #     mode = "markers",
    #     name = "custom",
    #     lat = df2['lon'],
    #     lon = df2['lat'],
    #     marker = {'size': 10,'color':'green','opacity':1}))
    # frames = [dict(
    #                                        'mapbox.center.lat' = df.loc[:k+1, 'lat'].values[0], 
    #                                        'mapbox.center.lon' = df.loc[:k+1, 'lng'].values[0]    
    #                   )for k  in  range(len(df))  
    # ]
    
    # df2 = race.position_data[['lon','lat']]
    
    # for row in df2.itertuples():
    #     fig.add_scattermapbox(
    #         mode = "markers+lines",
    #         lat = [row.lat],
    #         lon = [row.lon],
    #         marker = {'size': 10}
    #         )
    # print(df2)
    
    sliders = [
                {
                'x':0,#slider starting position  
                'y':0, 
                'active':num_loc,
                'len':1.0,
                'currentvalue': {'font': {'size':12}, 
                                    'prefix':'Point: ', 
                                    'visible':True, 
                                    'xanchor':'center'},
                "steps": [
                        {
                        "args": [{'mapbox.center.lat': df.loc[:k+1, 'lat'].values[k],
                                            'mapbox.center.lon': df.loc[:k+1, 'lng'].values[k],
                                            'mapbox.zoom': 15.2,
                                            'mapbox.pitch': 60}],
                        "label": str(df.loc[:k+1, 'location'].values[k]),
                        "method": "relayout",
                        }
                        for k in range(len(df))
                      ]
                          
                }
               ]

    print(df2)
    fig.update_layout(
            sliders=sliders
    )
    
    # fig.update_layout(updatemenus=[dict(
    #                                 y=0,
    #                                 x=1.05,
    #                                 xanchor='right',
    #                                 yanchor='top',
    #                                 pad=dict(t=0, r=10),
    #                                 buttons=[dict(label='Play',
    #                                               method='update',
    #                                               args=[None, 
    #                                                     dict(frame=dict(duration=1, 
    #                                                                     redraw=False),
    #                                                          transition=dict(duration=1),
    #                                                          fromcurrent=True,
    #                                                          mode='immediate'
    #                                                         )
    #                                                    ]
    #                                              )
    #                                         ]
                                    
    #                                )
                                   
    #                           ], 
    #                         sliders = sliders,
    #                   )
    
    
    # fig.update_layout(center = {"lat":24.467,"lon":54.607},accesstoken="mapbox://styles/connernations/clb052nkv002n14n00px0lu4u",
    #     'style':"mapbox://styles/connernations/clb052nkv002n14n00px0lu4u")
    # fig.update_mapboxes(pitch=60, zoom=15.6)
    # fig=px.Figure(px.Scattermapbox(
    #                lat=[df.loc[0, 'lat']],
    #                lon=[df.loc[0, 'lng']],
    #                mode='markers',
    #                marker=dict(size=10, color='red')
    #             ))
            
    
    
    # the last update can be performed simply as:
    #fig.update_mapboxes (the above unpacked dict); for beginners it's more clear the initial update 
    
    # fig.update_layout(
    #     mapbox = dict(
    #         accesstoken="pk.eyJ1IjoiY29ubmVybmF0aW9ucyIsImEiOiJjbGFxYXNsdjkxaDVnM3B0NzdodWN6MXFsIn0.tny5OHVo3KYLvoxY20ZkZg",
    #         style="mapbox://styles/connernations/clb052nkv002n14n00px0lu4u", center=dict(
    #             lat=16.467,
    #             lon=54.607
    #         ), zoom= 10))
    
    # button1 = dict(method='update',
    #               label='New2',
    #               args=[{"center":{"lat":26.467,"lon":54.607}}])
                    
    # button2 = dict(method='update',
    #               label='Bergeron',
    #              args=[{"center":{"lat":22.467,"lon":54.607}}])
                    
    # fig.update_layout(updatemenus=[dict(
    #             active=0,
    #             buttons=list([
    #                 dict(label="Q3",
    #                      method="update",
    #                      args=[{'mapbox':{"center":{"lat":22.467,"lon":54.607},'style': "mapbox://styles/connernations/clb052nkv002n14n00px0lu4u","zoom": .7}}
    #                            ]),
    #                 dict(label="Q4",
    #                      method="update",
    #                      args=[{'mapbox':{"center":{"lat":22.467,"lon":54.607}}}
    #                            ])
    # ])
    # )])
    
    # button1 = ({'label': 'Japan', 
    #             'method': 'relayout', 
    #             'args':[{'mapbox.center.lat': 34.8431,
    #                               'mapbox.center.lon':136.541,
    #                               'mapbox.zoom': 15.6,
    #                               'mapbox.pitch': 60}]})
    
    # button2 = ({'label': "Abu Dhabi", 
    #             'method': 'relayout', 
    #             'args':[{'mapbox.center.lat': 24.4672,
    #                               'mapbox.center.lon':54.6031,
    #                               'mapbox.zoom': 15.3,
    #                               'mapbox.pitch': 60}]})
    
    # fig.update_layout(updatemenus=[dict(active=0,
    #                                    buttons=[button1, button2])]
    #                 )

    return fig



# fig.plotly_restyle()
# fig.show()



# fig.plotly_restyle())
