import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats


def tire_analysis(year, race, temp=False, rain=False):
    driver_info = pd.read_parquet("Tire_Analysis/driver_info.parquet")
    
    data_18 = pd.read_csv('Tire_Analysis/tire_data_2018.csv')
    data_19 = pd.read_csv('Tire_Analysis/tire_data_2019.csv')
    data_20 = pd.read_csv('Tire_Analysis/tire_data_2020.csv')
    data_21 = pd.read_csv('Tire_Analysis/tire_data_2021.csv')
    data_22 = pd.read_csv('Tire_Analysis/tire_data_2022.csv')
    data_18['year']=2018
    data_19['year']=2019
    data_20['year']=2020
    data_21['year']=2021
    data_22['year']=2022
    
    frames = [data_22, data_21, data_20, data_19, data_18]

    data = pd.concat(frames).dropna()
    
    drivers = driver_info[['FullName', 'Tla']]
    drivers.columns =['FullName', 'Driver']   
    drivers.drop_duplicates(inplace=True)
    data = pd.merge(data, drivers, on=["Driver"])
    data.drop_duplicates(inplace=True)


    if year!='All years':
        data = data[data['year'] == year]
            

    if race!='All races':
        data = data[data['Event Name'] == race]
    else:
        data_g = data.groupby('Event Name')['LapTime'].mean().reset_index().rename({'LapTime':'LapTime_avg'},axis=1)
        data = pd.merge(data, data_g, on='Event Name')
        data['LapTime'] = data.LapTime/data.LapTime_avg
            
    drivers = ['All drivers'] + list(data['FullName'].unique())
    driver = st.selectbox('Select Driver:', options = drivers)
    if driver!='All drivers':
        data = data[data['FullName'] == driver]
    
    if temp:        
        temp_bool = st.checkbox('Air Temperature')
    
        if temp_bool:
            temps = data['Race Air Temp']
            temp_low, temp_high = st.slider('Select Air Temperature', temps.min(), temps.max()+1e-4, (temps.min(),temps.max()+1e-4))
            if temp:
                data = data[(data['Race Air Temp'] < temp_high + 2) & (data['Race Air Temp'] > temp_low - 2)]
         

    if rain:
        rain_bool = st.checkbox('Rainfall Pct')
    
        if rain_bool:
            rains = data['Pct Rainfall']
            rain_low,rain_high = st.slider('Select Rainfall Pct', rains.min(), rains.max()+1e-4, (rains.min(),rains.max()+1e-4))
            if rain:
                data = data[(data['Pct Rainfall'] < rain_high + 0.1) & (data['Pct Rainfall'] > rain_low - 0.1)]

    # tire_types = data.Compound.unique()

    tire_types = ['SOFT', 'MEDIUM', 'HARD', 'INTERMEDIATE', 'WET']

    z_thresh = 1

    fig, ax = plt.subplots()
    for i in tire_types: 
        data_compound = data[data['Compound'].str.contains(i)]['LapTime']
        data_compound = data_compound[(np.abs(stats.zscore(data_compound)) < z_thresh)]
        if data_compound.size >1: ax = data_compound.plot(kind='kde', label = i)
        
        
    plt.xlabel('Ratio of Lap Time to Avg')
    plt.ylabel('Density')
    plt.legend(ncol = 1)
    #plt.title(f'Distribution of Lap Times by Tire Composition at the {race}')
    return fig
