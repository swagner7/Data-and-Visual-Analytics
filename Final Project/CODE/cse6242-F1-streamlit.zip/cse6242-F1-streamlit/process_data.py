import pickle
from pathlib import Path
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from dataclasses import dataclass


def append_with_driver(obj):
    frames = []
    for driver, frame in obj["data"].items():
        frame["driver"] = driver
        frames.append(frame)

    return pd.concat(frames)


def append(obj):
    frames = []
    for _, frame in obj["data"].items():
        frames.append(pd.DataFrame(frame, index=[0]))

    return pd.concat(frames).reset_index()


def to_df(obj):
    return pd.DataFrame(obj["data"])


def identity(obj):
    return obj["data"]


functions = {
    "car_data": append_with_driver,
    "driver_info": append,
    "position_data": append_with_driver,
    "race_control_messages": to_df,
    "session_status_data": to_df,
    "timing_app_data": identity,
    "timing_data": identity,
    "track_status_data": to_df,
    "weather_data": to_df,
}


@dataclass
class Data:
    year: str
    race: str
    car_data: pd.DataFrame = None
    driver_info: pd.DataFrame = None
    position_data: pd.DataFrame = None
    race_control_messages: pd.DataFrame = None
    session_status_data: pd.DataFrame = None
    timing_app_data: pd.DataFrame = None
    sector_times: pd.DataFrame = None
    gap: pd.DataFrame = None
    track_status_data: pd.DataFrame = None
    weather_data: pd.DataFrame = None


base_path = Path.cwd() / "cache"

races = list()

for year_dir in base_path.iterdir():
    year = year_dir.name

    for race_dir in year_dir.iterdir():
        race = race_dir.name
        race_data = {"year": year, "race": race}

        for file in race_dir.rglob("*.ff1pkl"):
            with file.open("rb") as f:
                obj = pickle.load(f)

            if file.stem == "timing_data":
                sector_times, gap = functions[file.stem](obj)
                sector_times["year"] = year
                sector_times["race"] = race
                gap["year"] = year
                gap["race"] = race
                race_data["sector_times"] = sector_times
                race_data["gap"] = gap
            else:
                data = functions[file.stem](obj)
                data["year"] = year
                data["race"] = race
                race_data[file.stem] = data

        races.append(Data(**race_data))

for data in [
    "car_data",
    "driver_info",
    "position_data",
    "race_control_messages",
    "session_status_data",
    "timing_app_data",
    "sector_times",
    "gap",
    "track_status_data",
    "weather_data",
]:
    df = pd.concat([getattr(race, data) for race in races])
    table = pa.Table.from_pandas(df)
    pq.write_to_dataset(
        table,
        root_path=f"datasets/{data}",
        partition_cols=["year", "race"]
    )
