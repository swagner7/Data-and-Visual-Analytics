import fastf1 as ff1
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os


def get_overtake_data_by_year(year):
    data = []
    ff1.Cache.enable_cache('cache')
    for gp in range(1, 23):

        session = ff1.get_session(year, gp, 'race')
        session.load(telemetry=True)
        drivers = session.drivers
        total_overtakes = 0

        for driver in drivers:

            driver_info = session.get_driver(driver)
            driver_name = driver_info['BroadcastName']
            grid_pos = int(driver_info['GridPosition'])
            pos = int(driver_info['Position'])
            pos_change = grid_pos - pos
            points = driver_info['Points']

            drs_on_overtakes = 0
            drs_off_overtakes = 0

            telemetry = session.laps.pick_driver(driver).telemetry
            first_point = True

            for i, val in telemetry["DRS"].items():
                drs = val
                driver_ahead = telemetry["DriverAhead"].loc[i]
                distance_to_driver_ahead = telemetry["DistanceToDriverAhead"].loc[i]

                if first_point is False:
                    prev_driver_ahead = telemetry["DriverAhead"].loc[i - 1]
                    prev_distance_to_driver_ahead = telemetry["DistanceToDriverAhead"].loc[i - 1]

                    if prev_driver_ahead != '' and driver_ahead != prev_driver_ahead and distance_to_driver_ahead > prev_distance_to_driver_ahead and prev_distance_to_driver_ahead < 0.105:  # tune and add check with distance
                        total_overtakes += 1
                        if drs == 1:
                            drs_on_overtakes += 1
                        else:
                            drs_off_overtakes += 1

                first_point = False

            data.append([f'{session.event.year} {session.event.name}', driver_name, drs_on_overtakes, drs_off_overtakes,
                         drs_on_overtakes + drs_off_overtakes, grid_pos, pos, pos_change, points])

    df = pd.DataFrame(data,
                      columns=['Event', 'Driver', 'Overtakes with DRS', 'Overtakes without DRS', 'Total Overtakes',
                               'Grid Position', 'End Position', 'Change', 'Points'])

    return df


def plot_overtakes_drivers(data, save=False):
    # Get year
    year = data['Event'].iloc[0].split()[0]

    df_by_drivers = data.groupby('Driver', group_keys=False).sum()
    df_by_drivers = df_by_drivers.reset_index(level=0)
    df_by_drivers = df_by_drivers.sort_values(by='Total Overtakes',ascending=False)


    drivers = df_by_drivers['Driver'].to_numpy()
    overtakes_with_drs = df_by_drivers['Overtakes with DRS'].to_numpy()
    overtakes_without_drs = df_by_drivers['Overtakes without DRS'].to_numpy()
    # overtakes = df_by_drivers['Total Overtakes'].to_numpy()

    plt.rcdefaults()
    fig, ax = plt.subplots()
    y_pos = np.arange(len(drivers))

    ax.barh(y_pos, overtakes_with_drs, align='center', label='Overtakes with DRS')
    ax.barh(y_pos, overtakes_without_drs, align='center', label='Overtakes without DRS')
    ax.set_yticks(y_pos, labels=drivers)
    ax.invert_yaxis()

    ax.set_xlabel('Overtakes')
    ax.set_title(f'{year} Overtakes by Driver')

    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05),
              fancybox=True, shadow=True, ncol=5)

    fig.tight_layout()

    if save is True:
        plt.savefig(f'files/{year} Overtakes by Driver.png')
    else:
        plt.show()


def plot_overtakes_event(data, save=False):
    # Get year
    year = data['Event'].iloc[0].split()[0]

    df_by_event = data.groupby('Event', group_keys=False).sum()
    df_by_event = df_by_event.reset_index(level=0)
    df_by_event = df_by_event.sort_values(by='Total Overtakes', ascending=False)


    events = df_by_event['Event'].to_numpy()

    locations = []

    # Get name from event
    for e in events:
        arr = e.split()
        arr = arr[1:-2]
        loc = ' '.join(arr)
        locations.append(loc)

    overtakes_with_drs = df_by_event['Overtakes with DRS'].to_numpy()
    overtakes_without_drs = df_by_event['Overtakes without DRS'].to_numpy()

    # plt.rcdefaults()

    fig, ax = plt.subplots()

    y_pos = np.arange(len(locations))

    ax.barh(y_pos, overtakes_with_drs, align='center', label='Overtakes with DRS')
    ax.barh(y_pos, overtakes_without_drs, align='center', label='Overtakes without DRS')
    ax.set_yticks(y_pos, labels=locations)
    ax.invert_yaxis()

    ax.set_xlabel('Overtakes')
    ax.set_title(f'{year} Overtakes by Grand Prix')

    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05),
              fancybox=True, shadow=True, ncol=5)

    fig.tight_layout()

    if save is True:
        plt.savefig(f'files/{year} Overtakes by Grand Prix.png')
    else:
        plt.show()


if __name__ == '__main__':
    # Set SAVE_PLOT to True to save plot as png
    SAVE_PLOT = True

    filepath = 'files/experiment_data.csv'
    fileExist = os.path.exists(filepath)

    if fileExist is False:
        df = get_overtake_data_by_year(2021)
        df.to_csv(filepath)

    df = pd.read_csv(filepath)
    plot_overtakes_drivers(df, save=SAVE_PLOT)
    plot_overtakes_event(df, save=SAVE_PLOT)
